'root.trees'<-
function(trees, outgroup)
{
	rootedtree <- trees
	ntrees <- length(trees)
	phy<-read.tree(text=trees)

	for(i in 1:ntrees)
	{
		name <- species.name(trees[i])
		noname <- 0
		if(ntrees==1) a<-root(phy, outgroup=name[1], resolve.root=T)
		else a<-root(phy[[i]], outgroup=name[1], resolve.root=T)

		for(j in 1:length(outgroup))
		{
			if(length(grep(outgroup[j],name))>0)
			{
				a<-root(a, outgroup=outgroup[j], resolve.root=T)
				noname <- 1
				break
			}
		}
		if(noname==0) stop(paste("cannot find outgroup in tree", i))
	
		a$edge.length <- NULL
		a$node.label <- NULL
		a$root.length <- NULL
		rootedtree[i] <- write.tree(a)
	}
	return(rootedtree)
}

