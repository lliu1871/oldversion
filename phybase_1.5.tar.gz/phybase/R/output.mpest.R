'output.mpest'<-
function(mpestfile)
{
	x <- scan(mpestfile, what="character", sep="=")
	newname<-read.tree.string(mpestfile)$name
	y <- grep("tree mpest", x)
	z <- gsub("tree mpest \\[","",x[y])
	z <- as.numeric(gsub("\\]","",z))
	w <- x[y[which(z==max(z))[1]]+1]
	mptree <- gsub(" ","",node2name(w,newname))
	return(mptree)
}
